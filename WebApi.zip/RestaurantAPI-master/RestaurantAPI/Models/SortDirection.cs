﻿namespace RestaurantAPI.Models
{
    public enum SortDirection
    {
        ASC,
        DESC
    }
}
